## This software is licensed under the MIT "Expat" License.
## <http://opensource.org/licenses/MIT>

## Copyright (c) 2013–2015 Gray Calhoun

## Permission is hereby granted, free of charge, to any person
## obtaining a copy of this software and associated documentation
## files (the "Software"), to deal in the Software without
## restriction, including without limitation the rights to use, copy,
## modify, merge, publish, distribute, sublicense, and/or sell copies
## of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:

## The above copyright notice and this permission notice shall be
## included in all copies or substantial portions of the Software.

## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
## EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
## MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
## NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
## BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
## ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
## CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.

library(plyr)

extract_data <- function(plotvar, groupvar,
                         filename = "reinhart_rogoff_data.txt",
                         debt.threshold = 90,
                         gdp.threshold = 1,...) {
  RR <- read.delim(file = filename, sep = "|", stringsAsFactors = FALSE,...)
  for (i in setdiff(names(RR), c("Country", "Year"))) {
    RR[,i] <- as.numeric(RR[,i])
  }
  
  ## These choices have been taken directly from Herndon, Ash and
  ## Pollin's R code.  I have been unable to find an explanation for
  ## the choices, so I'm going to take them as given and move on, but
  ## am happy to change them in the future. (2013-04-23)
  RR$debt.ratio <- NA
  RR$gdp.growth <- NA

  
  RR <- within(RR, debt.ratio <- ifelse(Country=="Australia",ifelse(Year<=1948,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Austria",ifelse(Year<=1979,100*Debt1/GDP1,100*Debt2/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Belgium",ifelse(Year<=1979,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Canada",ifelse(Year<=1948,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Denmark",ifelse(Year<=1949,100*Debt1/GDP1,100*Debt1/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Finland",ifelse(Year<=1977,100*Debt1/GDP1,100*Debt2/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="France",ifelse(Year<=1948, 100*Debt1 / GDP1, ifelse(Year<=1978, 100*Debt1 / GDP2,100*Debt2/GDP2)),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Germany",ifelse(Year<=1950,100*Debt1/GDP1,100*Debt2/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Greece",ifelse((Year>=1884 & Year<=1913) | (Year>=1919 & Year<=1939) | (Year>=1970 & Year<=1992),100*Debt/GDP1, ifelse(Year==2009,100,debt.ratio)),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Ireland",ifelse(Year<=2010,100*Debt/GDP2,debt.ratio),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Italy",ifelse(Year<=1913,100*Debt/GDP1,ifelse(Year<=1946,100*Debt/GNI,ifelse(Year<=1998,100*Debt/GDP1,100*Debt/GDP2))),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Japan",ifelse(Year<=1953,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Netherlands",ifelse(Year<=1956,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="New Zealand",ifelse(Year<=1947,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Norway",ifelse(Year<=1948,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Portugal",ifelse(Year<=1999,100*Debt1/GDP1,100*Debt2/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Spain",ifelse(Year<=1957,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="Sweden",ifelse(Year<=1949,100*Debt/GDP1,100*Debt/GDP2),debt.ratio))
  RR <- within(RR, debt.ratio <- ifelse(Country=="UK" , 100*Debt/GDP, debt.ratio ))
  RR <- within(RR, debt.ratio <- ifelse(Country=="US" , 100*Debt/GDP, debt.ratio ))

  RR <- ddply( RR, ~Country, transform, lRGDP=lg(RGDP), lRGDP1=lg(RGDP1), lRGDP2=lg(RGDP2)  )
  RR <- within(RR, gdp.growth <-
      ifelse(!is.na(gdp.growth), gdp.growth,
      ifelse(!is.na(log(RGDP) -  log(lRGDP)), 100 * (log(RGDP) - log(lRGDP)),
      ifelse(!is.na(log(RGDP2) - log(lRGDP2)), 100 * (log(RGDP2) - log(lRGDP2)),
      ifelse(!is.na(log(RGDP1) - log(lRGDP1)), 100 * (log(RGDP1) - log(lRGDP1)), NA)))))

  ## This kills one observation for the Netherlands (in 1940) where
  ## there must be a switch in measurement procedure
  RR$gdp.growth[RR$gdp.growth > 200] <- NA
  ## Extra label to make all the graphs comparable
  RR$all <- "All countries"

  ## Data restrictions from the original code
  RR <- subset(RR,Year>=1946 & Year<=2009)
  RR <- subset(RR, !(Year<1951 & Country=="Italy"))
  ## To make it easier to graph, I only want periods where both are
  ## available
  RR$gdp.growth[is.na(RR$gdp.growth) | is.na(RR$debt.ratio)] <- NA
  RR$debt.ratio[is.na(RR$gdp.growth) | is.na(RR$debt.ratio)] <- NA
  RR$debt.threshold <- ifelse(is.na(RR$debt.ratio), FALSE,
                              RR$debt.ratio > debt.threshold)
  RR$gdp.threshold <- ifelse(is.na(RR$gdp.growth), TRUE,
                             RR$gdp.growth > gdp.threshold)

  return(na.padding(subset(RR,
    select = c(Year, Country, debt.ratio, gdp.growth,
               debt.threshold, gdp.threshold, all)), plotvar, groupvar))
}

## pad with NAs liberally so that I can automatically get line breaks
## in the graphs
na.padding <- function(d, plotvar, groupvar) {
  do.call(rbind, lapply(split(d, d$Country), function(x) {
    do.call(rbind, lapply(unique(x[,groupvar]), function(g) {
      xx <- x
      xx[xx[,groupvar] != g, plotvar] <- NA
      xx[,groupvar] <- g
      xx[order(xx$Year),]
    }))
  }))
}


lg <- function(x) {
  len <- length(x)
  if (len > 0) {
    c(NA, x[seq_len(length = len - 1)])
  } else {
    numeric(0)
  }
}

library(lattice)
d <- extract_data("debt.ratio", "gdp.threshold")

pdf(file = "graphs/debt_overview.pdf", height = 4, width = 6)
xyplot(debt.ratio ~ Year | all, lwd = c(1.5,1), data = d, cex = c(.4, .25),
       strip = FALSE,
       group = interaction(d$gdp.threshold, d$Country),
       col = c(rgb(0,0,0,1), rgb(0,0,0,.2)), type = "b",
       ylab = "Debt/GDP ratio")
dev.off()

pdf(file = "graphs/gdp_regression.pdf", height = 7, width = 6)
coplot(gdp.growth ~ log(debt.ratio) | Year, data = d,
       given.values = co.intervals(d$Year, 9, overlap = 0),
       xlab = "log(real debt/real GDP)",
       ylab = "real GDP growth rate",
       col = rgb(0,0,0,.75), panel = panel.smooth)
dev.off()

d$Ddebt = unlist(by(d$debt.ratio, d$Country, function(x) c(NA, diff(log(x)))))
pdf(file = "graphs/debt_regression.pdf", height = 7, width = 6)
coplot(Ddebt ~ gdp.growth | Year, data = d, cex = 0.8,
       given.values = co.intervals(d$Year, 9, overlap = 0),
       ylab = "Change in log(real debt/real GDP)",
       xlab = "Real GDP growth rate", xlim = c(-10, 20),
       col = rgb(0,0,0,.75), panel = panel.smooth)
dev.off()

pdf(file = "graphs/debt_regression2.pdf", height = 7, width = 6)
coplot(Ddebt ~ gdp.growth | Year + log(debt.ratio), data = d,
       given.values = list(co.intervals(d$Year, 3, overlap = 0),
           co.intervals(log(d$debt.ratio), 4, overlap = 0)),
       ylab = c("Next period change in log(real debt/real GDP)", "Given: log(real debt/real GDP)"),
           cex = 0.8,
       xlab = "Real GDP growth rate", xlim = c(-10, 20),
       col = rgb(0,0,0,.75), panel = panel.smooth)
dev.off()

pdf(file = "graphs/country_debt.pdf", height = 7, width = 6)
xyplot(debt.ratio ~ Year | Country, data = d, cex = c(.25, .4),
       group = 1 - gdp.threshold, col = c("gray", "black"), type = "b",
       ylab = "Debt/GDP ratio")
dev.off()
