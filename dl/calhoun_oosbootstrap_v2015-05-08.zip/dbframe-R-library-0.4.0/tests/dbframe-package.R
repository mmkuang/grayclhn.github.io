## Copyright (C) 2010-2015 Gray Calhoun; MIT license

library(testthat)
test_package("dbframe")
