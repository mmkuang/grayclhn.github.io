latexfiles
==========

Files that I typically need to include in LaTeX documents.

* `references.bib` - a comprehensive BibTeX database

* `tcilatex.tex` - LaTeX file that's necessary when coauthors use
  Scientific Word