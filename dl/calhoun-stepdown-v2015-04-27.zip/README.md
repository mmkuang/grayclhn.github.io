Improved stepdown methods for asymptotic control of generalized error rates
===========================================================================

This directory contains the code necessary to run the analysis for my
paper, "Improved stepdown methods for asymptotic control of
generalized error rates." I am making this code available so that
other researchers can verify and reproduce my results, but I have no
plans to develop it into a stand-alone package.

This repository is for the 2015-04-27 version of the
document. See below for a terse version history.

Download
-------- 

This code should be available at
<https://git.ece.iastate.edu/gcalhoun/stepdown-paper>. The latest
version of the paper accompanying this code should be available at
<http://gray.clhn.org>.

Version history
---------------

+ 2015-04-27: Set up this versioning system (which has been backported)
+ 2014-09-24: Submitted to *Journal of Econometrics*
+ 2014-09-22: Presented at 2014 JSM in Boston
+ 2014-07-08: Presented at 2014 NBER Summer Institute
+ 2014-06-11: Submitted to *Econometrica* (subsequently rejected)
+ 2014-03-13: Submitted to 2014 NBER Summer Institute (subsequently accepted)
+ 2013-10-07: Submitted to Annals of Statistics (subsequently rejected)
+ 2013-09-11: Presented at Iowa State Labor Workshop
+ 2011-10-03: Emailed to Joe Romano and Michael Wolf for informal feedback

Execution and Organization
--------------------------

The paper's analysis can be executed in its entirety by typing "make"
at the command line, assuming that you have the necessary software
installed (see the 'Dependencies' section for details).  The file
'Makefile' is read by GNU Make and specifies the order of execution of
each part of the program.  Note that GNU Make will not recreate a file
if it is newer than all of the other files it depends on, so typing
'make' will not regenerate files unnecessarily.

The `R` folder contains R code for the simulations and empirical
analysis in the paper: `empirics.R` runs the empirical analysis, and
`empiricsoutput.R` formats the results for the paper; similarly
`simulations.R` runs the monte carlo simulations and
`simulationsoutput.R` formats the results. All of these scripts are
relatively straightforward and just manage the analysis.

The subfolder `R/package` contains the source code for the estimators
used in the paper. The subfolders `R/Combinations-0.2.0` and
`R/dbframe-0.3.3` contain the source code for some external packages
used in this paper. And the `matlab` directory contains Matlab code
written by Andrews and Barwick for their 2012 Econometrica paper.

I do not have a license to redistribute the empirical data used in
this paper, so it is not in the repository. The final tables are
included in the repository as `tex/empirics.tex`.

Dependencies
------------

The following software is required to do the paper's analysis and
build a pdf of the paper.

* R (version 2.14.1 or higher) and the following packages:
  - xtable
  - MASS
  - sandwich
  - R.utils
  - R.matlab
  - parallel
  - Combinations (source code included in `R/`)
  - dbframe (source code included in `R/`)
* GNU Make
* pdflatex and latexmk (Additional LaTeX packages are required as
  well; see `tex/styleheader.tex` for a list.)

License and copying
-------------------

Most of the files are copyright Gray Calhoun (2013-2015) and licensed
under the [MIT "Expat" License](http://opensource.org/licenses/MIT):

> Permission is hereby granted, free of charge, to any person
> obtaining a copy of this software and associated documentation
> files (the "Software"), to deal in the Software without
> restriction, including without limitation the rights to use, copy,
> modify, merge, publish, distribute, sublicense, and/or sell copies
> of the Software, and to permit persons to whom the Software is
> furnished to do so, subject to the following conditions:
>
> The above copyright notice and this permission notice shall be
> included in all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
> EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
> MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
> NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
> BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
> ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
> CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
> SOFTWARE.

But there are exceptions.

- The file 'paper.tex' is the main text and is not available under an
  open source license.

- The files in the `matlab` subdirectory were written by Andrews and
  Barwick and can be downloaded from
  <http://www.econometricsociety.org/suppmat.asp?id=423&vid=80&iid=6&aid=13>
  I obviously don't own the copyright for those files and their
  licensing status is ambiguous. I use the code in my analysis and so
  I have included the files here for completeness. Also see
  `matlab/README_AndrewsBarwick`.

- The files in `R/Combinations-0.2.0` were written by Duncan Temple
  Lang and are available under the BSD license; see
  `R/Combinations-0.2.0/LICENSE_BSD` for details. (This is essentially
  the same as the MIT Licensee.)

Note that I'm the author of the package in `R/dbframe-0.3.3` and I'm
relicensing it here under the MIT license.

Contacts
--------

Please email Gray Calhoun <gcalhoun@iastate.edu> with any questions or
comments about this software.
