### Copyright (c) 2011-2015 Gray Calhoun.

mcs <- replicate(30000, {
  sum(rnorm(332) > 1.64)
})

pdf(width = 8, height = 5, file = "floats/hist332.pdf")
hist(mcs, seq(2.5, 35.5, 1), xlim = c(0, 35), freq = FALSE,
     main = "Histogram of rejections for 332 independent t-tests",
     xlab = "Number of tests > 1.64 (5% critical value)", col = "alice blue")
dev.off()

mcs <- replicate(30000, {
  sum(rnorm(10) > 1.64)
})

pdf(width = 8, height = 5, file = "floats/hist5.pdf")
hist(mcs, freq = FALSE, seq(-0.5, 5.5, 1), xlim = c(-.5, 10),
     main = "Histogram of rejections for 10 independent t-tests",
     xlab = "Number of tests > 1.64 (5% critical value)", col = "alice blue")
dev.off()


X <- matrix(rnorm(200 * 50), 200, 50)
qnorm(1 - .05/50)

tstats <- function(mat) {
  n <- nrow(mat)
  apply(mat, 2, function(x) sqrt(n) * mean(x) / sd(x))
}

M <- replicate(9999,
               max(abs(tstats(X[sample(1:200, 200, replace = TRUE),]))))
hist(M, 80, col = "alice blue")
quantile(M, .9)
