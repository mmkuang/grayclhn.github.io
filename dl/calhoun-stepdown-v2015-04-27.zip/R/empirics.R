### Copyright (c) 2011-2015 Gray Calhoun

### Set monte-carlo design parameters
nboot <- 1499
size <- 0.05
blocklength <- 15

### Load data:
### - risk free rate (benchmark returns)
### - CISDM hedge fund indices
### - CISDM individual active hedge funds
### - CISDM hedge funds that have "died"

rfree <- read.table("data/benchmark.txt", header = FALSE)
names(rfree) <- c("date", "market", "tbill")
rfree <- ts(rfree[,2:3], start = c(1926, 7), freq = 12)

indices <- read.csv("data/cisdm_indices.csv")
indices <- ts(indices[,-1], start = c(1994, 1), freq = 12)
indexnames <- paste("CISDM", colnames(indices))

funds <- read.csv("data/cisdm_funds.csv", stringsAsFactors = FALSE)
funds <- funds[!is.na(funds[,4]),]
fundnames <- funds[,2]
funds <- t(funds[,-(1:3)])
row.names(funds) <- NULL
funds <- ts(funds, start = c(1994, 1), freq = 12)

deads <- read.csv("data/cisdm_dead.csv", stringsAsFactors = FALSE)
deads <- deads[!is.na(deads[,2]),]
deadnames <- deads[,1]
deads <- deads[,-1]
deads <- ts(t(deads), start = c(1994, 1), freq = 12)

fnames <- c(indexnames, fundnames, deadnames)
livefund <- c(rep(TRUE, ncol(indices) + ncol(funds)),
              rep(FALSE, ncol(deads)))
## f <- window(cbind(indices, funds, deads) - rfree[,"market"],
##             start = c(1994, 1), end = c(2011, 12))
f <- window(log(1 + cbind(indices, funds, deads) / 100)
            - log(1 + rfree[,"tbill"] / 100),
            start = c(1994, 1), end = c(2011, 12))
colnames(f) <- NULL

library(Combinations, lib.loc = "R")
library(dbframe, lib.loc = "R")
library(stepdown, lib.loc = "R")
library(sandwich)

stdev <- function(x) {
  x <- x[!is.na(x)]
  sqrt(drop(vcovHAC(lm(x ~ 1), prewhite = TRUE)))
}

tboot <- function(x, blockstarts, blocklengths) {
  stopifnot(is.vector(x))
  xbar <- mean(x, na.rm = TRUE)
  x <- x - xbar
  nobs <- length(x)
  blocks <- sapply(seq_along(blockstarts), function(i) {
    xi <- x[1 + (seq.int(from = blockstarts[i] - 1, 
                         length = blocklengths[i]) %% nobs)]
    notna <- !is.na(xi)
    c(sum = sum(xi[notna]),
      sq = sum(outer(xi[notna], xi[notna])))
  })
  sum(blocks[1,]) / sqrt(sum(blocks[2,]))
}

boots <- RepParallel(nboot, {
  nblock <- ceiling(ncol(f) / blocklength)
  blocks <- c(rep(blocklength, nblock - 1),
              blocklength + ncol(f) - sum(rep(blocklength, nblock)))
  blockstart <- sample(seq_len(ncol(f)), nblock, TRUE)
  apply(f, 2, function(y) tboot(y, blockstart, blocks))
})

newm <- function(tf, mold) {
  frm <- tf$frame[tf$frame$t > tf$c,]
  mm <- frm$m - tf$c * frm$s
  mnew <- min(mm)
  if (isTRUE(all.equal(mold, mnew))) {
    mnew <- mnew + 0.000000001
  }
  return(mnew)
}

## g = NA means that we're doing the 1-StepM
## otherwise control the FDR
gett <- function(m, g = NA) {
  means <- apply(f, 2, function(x) mean(x, na.rm = TRUE))
  stdevs <- apply(f, 2, stdev)
  tstats <- (means - m) / stdevs

  critvals <- stepm(tstats, boots, size, 1, lcut = TRUE)
  k <- 1
  if (!is.na(g)) {
      while (k/g < sum(critvals[2] < tstats)) {
          k <- k + 1
          print(k)
          critvals <- stepm(tstats, boots, size, k, lcut = TRUE)
      }
  } 
  list(c = critvals[2], k = k,
       frame = data.frame(m = means, s = stdevs, t = tstats))
}

testfunds <- function(size = 0.05, g = NA) {
    m <- 0
    tf <- gett(m, g)
    tf0 <- tf$frame
    tf0$left <- NA
    tf0[tf0$t < tf$c,"left"] <- -Inf
    rownames(tf0) <- fnames

    while (sum(tf$c < tf$frame$t) > 0) {
        m <- newm(tf, m)
        tf <- gett(m, g)
        pos <- which(is.na(tf0$left) & tf$frame$t <= tf$c)
        tf0[pos,"left"] <- m
        print(tf0[pos,])
        cat(sum(tf$c < tf$frame$t), ": ", sprintf("%.10f", m), "\n", sep = "")
    }
    tf0
}

funds_fwe <- testfunds()
funds_fdr <- testfunds(g = 0.1)
### Save data
save.image(file = "data/empirics.RData")
