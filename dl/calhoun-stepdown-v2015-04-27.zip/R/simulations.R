### Copyright (c) 2011-2015 Gray Calhoun

options(warn = 1)
library(Combinations, lib.loc="R")
library(dbframe, lib.loc="R")
library(stepdown, lib.loc="R")

set.seed(c(654, 1249, 132, 6, 8, 9), kind = "L'Ecuyer-CMRG")

nsims <- 1000
nboot <- 999
mcdesign <- rbind(expand.grid(type = 1:6, nobs = c(50, 100), lev = 5),
                  data.frame(type = 8:10, nobs = 100, lev = 5))

## Initialize SQLite database to store results
mcsetup <- dbframe("mcsetup", "data/montecarlo.db")
clear(mcsetup)
insert(mcsetup) <- data.frame(variable = c("nsims", "nboot"),
                              value = c(nsims, nboot))
mcdata <- dbframe("mcdata", "data/montecarlo.db")
clear(mcdata)

## Initialize MATLAB server for Andrews and Barwick's code
Matlab$startServer()
matlab <- Matlab()
open(matlab)
Sys.sleep(120)
evaluate(matlab, "addpath('./matlab');")

## The simulation code follows; obviously most of the work is done in
## "rdgp" and "dotests", which are both in the stepdown package.
for (r in rows(mcdesign)) {
  for (i in 1:nsims) {
    print(paste(r$type, "-", i, "/", nsims))
    d <- rdgp(r$type, r$nobs)
    insert(mcdata) <-
      data.frame(r, row.names = NULL,
                 dotests(d$x - d$y, r$type, r$lev / 100, nboot, matlab))
  }
}

close(matlab)
