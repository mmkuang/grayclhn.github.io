### Copyright (c) 2011-2015 Gray Calhoun

library(dbframe, lib.loc="R")
mcdata <- dbframe("mcdata", "data/montecarlo.db")
mcsetup <- dbframe("mcsetup", "data/montecarlo.db")

maketable <- function(stats, colheads, mainheads,
    errortemplate = "100 * avg(case when stat = '%s' then 
      case when type in (7,9,10) then NULL else error end end)",
    powertemplate = "avg(case when stat = '%s' then 
      case when type in (1,2,8) then NULL else ncorrect end end)",...) {

  errorsql <- sprintf(errortemplate, stats)
  powersql <- sprintf(powertemplate, stats)
  names(errorsql) <- names(powersql) <- letters[seq_along(stats)]
  
  mcframe <-  select(mcdata, group.by = c("nobs", "type"),
                     order.by = c("nobs ASC", "type ASC"),
                     c(errorsql, powersql,
                       nfalse = "case when type in (1,2,8) then 0
                                      when type in (3,4) then 6
                                      when type in (5,6) then 20
                                      when type = 7 then 40
                                      when type in (9,10) then 2 end"),...)
  names(mcframe) <- c("\\#~Obs.", "Type",
                      colheads, colheads, "\\#~False")

  ncol <- length(colheads)
  latextable <- booktabs(mcframe, numberformat = TRUE,
                         align  = c(rep("c", 2), rep("C", 1 + 2 * ncol)),
                         digits = c(rep(0, 2), rep(1, 2 * ncol), 0),
                         purgeduplicates = c(TRUE, rep(FALSE, 2 + 2 * ncol)))
  latextable <- sub(fixed = TRUE, "\\toprule",
                    sprintf("\\toprule & & \\multicolumn{%d}{c}{%s} &
                             \\multicolumn{%d}{c}{%s} \\\\
                             \\cmidrule(lr){%d-%d} \\cmidrule(lr){%d-%d}",
                            ncol, mainheads[1], ncol, mainheads[2], 3, 2 + ncol,
                            3 + ncol, 2 + 2 * ncol), latextable)
  latextable <- sub(fixed = TRUE, "$100$", "\\addlinespace $100$", latextable)
  latextable
}

texcommand <- function(macro, tex)
  sprintf("\\newcommand{\\%s}{%s}\n", macro, as.character(tex))

fweLatex <- maketable(c("ours1", "RW1", "SPA"),
                      c("Ours", "StepM", "\\allcaps{SPA}"),
                      c("Familywise error rate (\\%)", "Average \\# discoveries"),
                      where = "type < 7")

kfweLatex <- maketable(c("oursk", "RWk"), c("Ours", "$k$-StepM"),
                       c("$k$-familywise error rate (\\%)", "Average \\# discoveries"),
                       where = "type in (2,3,4,5,6)")

sizeLatex <- maketable(c("ours1", "Bon", "AQLR"),
                       c("Ours", "Bon.", "\\allcaps{AQLR}"),
                       c("Size (\\%)", "Power (\\%)"),
                       where = "type in (1,8,9,10) and nobs = 100",
                       powertemplate = "100 * avg(case when stat = '%s' then 
                         case when type in (1,2,8) then NULL else ncorrect OR error end end)")
            
cat(file = "tex/simulations.tex",
    texcommand("mcfwe", fweLatex),
    texcommand("mckfwe", kfweLatex),
    texcommand("mcsize", sizeLatex),
    texcommand("nsims", select(mcsetup, "value", where = "variable='nsims'")),
    texcommand("mcboot", select(mcsetup, "value", where = "variable='nboot'")))
