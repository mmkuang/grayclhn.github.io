### Copyright (c) 2011-2015 Gray Calhoun

require(dbframe, lib.loc="R")
require(tikzDevice)
load("data/empirics.RData")

crit_fwe <- min(funds_fwe$t[funds_fwe$left > 0])

headers <- c("", "\\allcaps{LB} (\\%)", "Avg. (\\%)", "$t$-stat")

tflive <- data.frame(fund = NA,
                     funds_fdr[funds_fdr$left > 0 & livefund,c("left", "m", "t")])
tflive <- tflive[order(tflive$left),]
tflive$m <- 1200 * tflive$m
tflive$left <- 1200 * tflive$left
tflive$fund <- gsub("\\&", "\\\\&",
                    paste(rownames(tflive), ifelse(tflive$t > crit_fwe, "*", " ")))
names(tflive) <- headers

tfdead <- data.frame(fund = NA,
                     funds_fdr[funds_fdr$left > 0 & !livefund,c("left", "m", "t")])
tfdead <- tfdead[order(tfdead$left),]
tfdead$m <- 1200 * tfdead$m
tfdead$left <- 1200 * tfdead$left
tfdead$fund <- gsub("\\&", "\\\\&",
                    paste(rownames(tfdead), ifelse(tfdead$t > crit_fwe, "*", " ")))
names(tfdead) <- headers

textemplate <- function(command, tex)
  sprintf("\\newcommand{\\%s}{%s}\n", command,
          as.character(tex))

tableformat <- function(frame)
  booktabs(frame, align = c("l", rep("C", 3)),
           digits = 2, numberformat = c(FALSE, rep(TRUE, 3)))

nmiss <- apply(funds, 2, function(y) sum(is.na(y)))
nmissd <- apply(deads, 2, function(y) sum(is.na(y)))

histfile <- "tex/empirics_temporary.tex"
tikz(file = histfile, height = 2.5, width = 5.5)
hist(nmiss[nmiss > 0], 50, col = "alice blue", xlim = c(0, 80),
     ylim = c(0, 25), las = 1, cex.axis = .75,
     main = "Number of missing observations in each active fund",
     xlab = NULL)
dev.off()

deadfile <- "tex/empirics_temporary2.tex"
tikz(file = deadfile, height = 2.5, width = 5.5)
hist(nmissd[nmissd > 0], 80, col = "alice blue", xlim = c(0, 80),
     ylim = c(0, 25), las = 1, cex.axis = .75,
     main = "Number of missing observations in each closed fund",
     xlab = NULL)
dev.off()

cat(file = "tex/empirics.tex",
    textemplate("fundstable", tableformat(tflive)),
    textemplate("deadstable", tableformat(tfdead)),
    textemplate("sizeempirics", 100 * size),
    textemplate("nbootempirics", nboot),
    textemplate("blocklength", blocklength),
    textemplate("nlive", length(fundnames)),
    textemplate("ndead", length(deadnames)),
    textemplate("nindex", length(indexnames)),
    textemplate("ntotal",
                length(fundnames) + length(deadnames) + length(indexnames)),
    textemplate("nmonth", nrow(f)),
    textemplate("nmiss", sum(apply(f, 2, function(y) any(is.na(y))))),
    textemplate("fundshist", paste(readLines(histfile), collapse="\n")),
    textemplate("deadshist", paste(readLines(deadfile), collapse="\n")))

file.remove(histfile, deadfile)
