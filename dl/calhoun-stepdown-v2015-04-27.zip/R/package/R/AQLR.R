### Copyright (c) 2011-2013 Gray Calhoun.

### This program is free software: you can redistribute it and/or 
### modify it under the terms of the GNU General Public License as 
### published by the Free Software Foundation, either version 3 of 
### the License, or (at your option) any later version.

### This program is distributed in the hope that it will be useful,
### but WITHOUT ANY WARRANTY; without even the implied warranty of 
### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
### GNU General Public License for more details.

### You should have received a copy of the GNU General Public License 
### along with this program. If not, see 
### <http://www.gnu.org/licenses/>.

## This function is just a wrapper for Andrews and Barwick's MATLAB
## code; the default values of the arguments are taken from their code
## as well.  See their code for further documentation.

AQLR <- function(x, matlab, sig = 0.05, stattype = 2.5, cvtype = 1011,
                 kappa = 0, blocklength = 1000, nblock = 10) {

  xbar <- sqrt(nrow(x)) * colMeans(x)
  dim(xbar) <- c(ncol(x), 1)
  vhat <- cov(x)

  ## Note that our code uses the opposite sign restrictions as Andrews
  ## and Barwick's, so we pass the negative of xbar and x to MATLAB.
  setVariable(matlab, sig = sig, xbar = - xbar, x = -x,
              vhat = vhat, kappa = kappa)
  statcode <- sprintf("statval = STAT(xbar', vhat, %.1f);", stattype)
  critcode <- sprintf("critval = CRITVALS(xbar, vhat, x, %.1f, %d, kappa, sig, %d, %d);",
                      stattype, cvtype, blocklength, nblock)
  
  evaluate(matlab, statcode)
  evaluate(matlab, critcode)

  results <- getVariable(matlab, c("statval", "critval"))
  return(c(test = drop(results$statval > results$critval),
           stat = drop(results$statval),
           crit = drop(results$critval)))
}
