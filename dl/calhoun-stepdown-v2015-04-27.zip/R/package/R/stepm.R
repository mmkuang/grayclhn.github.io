## Copyright (c) 2011-2013 by Gray Calhoun
 
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or (at
## your option) any later version.

## This program is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
## General Public License for more details.

## For a copy of the GNU General Public License, please see
## <http://www.r-project.org/Licenses/>.

newbootapply <- function(boots, FUN) {
  ## Returns a function; this function takes a vector indexing rows of
  ## the bootstrap replications and applies FUN to those rows
  cols <- seq_len(ncol(boots))
  rows <- seq_len(nrow(boots))
  fn <- function(i = rows) {
    simplify2array(mclapply(cols, function(col) FUN(boots[i,col])))
  }
  return(fn)
}

bonftest <- function(tests, boots, lev, trim = lev/10) {
  ## Cryptic(?).  The next commands use 'newbootapply' to create a new
  ## annonymous function that applies 'min' and 'max' across the
  ## bootstrap replications, then immediately calls that function
  ## (hence the second set of parens) and stores the values it
  ## returns.
  bootmins <- newbootapply(boots, min)()
  qleft <- quantile(bootmins, trim)
  bootmaxs <- newbootapply(boots, max)(tests > qleft)
  qright <- quantile(bootmaxs, 1 - lev + trim)
  return(c(min(qleft, 0), max(0, qright)))
}

stepm <- function(tests, boots, lev, k=1, lcut = FALSE, rcut = FALSE) {
  if (k == 1) return(stepm1(tests, boots, lev, lcut))  
  statorder <- order(tests)
  tests <- tests[statorder]
  boots <- boots[statorder,,drop=FALSE]
  
  nstat <- length(tests)
  stopifnot(k <= nstat)

  qmin <- setqmin(lcut, tests, boots)
  qmaxk <- setqmaxk(rcut, lev, k, tests, boots)

  ppos.top <- 1
  qpos.top <- rep(nstat, k)

  repeat {
    if (qpos.top[1] - qpos.top[k] >= k) {
      ## Watch out while debugging; the next line can crash R if the
      ## previous criterion doesn't hold (so `getcrits` probably
      ## should be fixed!)
      critvals <- getcrits(qmin, qmaxk, ppos.top, qpos.top, k)
      pcrit <- critvals[1]
      qcrit <- critvals[-1]
    } else {
      cindex <- seq.int(ppos.top, max(qpos.top[1], ppos.top + k - 1), 1)
      pcrit <- qmin(cindex)
      qcrit <- qmaxk(cindex)
    }
    ppos <- max(getppos(pcrit, tests), ppos.top)
    qpos <- pmin(getqpos(qcrit, tests), qpos.top)
    ## If nothing productive happened last time through the loop, or
    ## we're out of hypotheses, stop
    if (qpos[k] - ppos < 0 || (all(qpos == qpos.top) && ppos == ppos.top)) {
      break
    }
    ppos.top <- ppos
    qpos.top <- qpos
  }
  return(unname(c(pcrit, qcrit[k])))
}

## Streamlined code for 1-stepm
stepm1 <- function(tests, boots, lev, lcut = FALSE) {
  statorder <- order(tests)
  tests <- tests[statorder]
  boots <- boots[statorder,,drop=FALSE]
  
  nstat <- length(tests)

  qmin <- setqmin(lcut, tests, boots)
  qmax <- setqmax(lev, tests, boots)

  ppos.top <- 1
  qpos.top <- nstat
  repeat {
    cindex <- seq.int(ppos.top, qpos.top, 1)
    pcrit <- qmin(cindex)
    ppos <- getppos(pcrit, tests)

    qcrit <- qmax(cindex)
    qpos <- getqpos(qcrit, tests)

    ## If "nothing productive happened" or we ran out of hypotheses
    ## then stop the loop
    if (qpos - ppos < 0 || ((qpos == qpos.top) && ppos == ppos.top)) {
      break
    }
    ppos.top <- ppos
    qpos.top <- qpos
  }
  return(unname(c(pcrit, qcrit)))
}


setqmin <- function(lcut, tests, boots) {
  if (isTRUE(!lcut) || is.null(lcut) || is.na(lcut)) {
    lcut <- -Inf
  }
  if (is.numeric(lcut)) {
    qmin <- function(index) {
      return(lcut)
    }
  } else {
    bootmin <- newbootapply(boots, min)
    qmin <- function(index) {
      return(min(bootmin(index)))
    }
  }
  return(qmin)
}

setqmax <- function(lev, tests, boots) {
  bootmax <- newbootapply(boots, max)
  function(index) {
    return(max(0, quantile(bootmax(index), 1 - lev)))
  }
}

setqmaxk <- function(rcut, lev, k, tests, boots) {
  nstat <- length(tests)
  bootmaxk <- newbootapply(boots, function(x) {
    kindex <- seq_len(min(k, length(x)))
    -sort.int(-x, partial=kindex)[kindex]
  })
  if (isTRUE(any(!rcut)) || any(is.null(rcut)) || any(is.na(rcut))) {
    rcut <- rep(Inf, k-1)
  }
  if (is.numeric(rcut)) {
    stopifnot(length(rcut) == k-1)
    qmaxk <- function(index) {
      return(pmax(0, c(rcut, quantile(bootmaxk(index)[k,], 1 - lev))))
    }
  } else {
    qmaxk <- function(index) {
      bootmaxes <- bootmaxk(index)
      return(pmax(0, c(apply(bootmaxes[seq_len(k-1),, drop = FALSE], 1, max),
                       quantile(bootmaxes[k,], 1-lev))))
    }
  }
  return(qmaxk)
}

getppos <- function(pcrit, tests) {
  lindex <- 1
  if (tests[lindex] < pcrit) {
    pos <- which.min(tests < pcrit)
  } else {
    pos <- lindex
  }
  return(pos)
}

getqpos <- function(qcrit, tests) {
  rindex <- length(tests)
  pos <- sapply(qcrit, function(cv) {
    if (tests[rindex] > cv) {
      which.max(tests > cv) - 1
    } else {
      rindex
    }
  })
  return(pos)
}

getcrits <- function(qmin, qmaxk, ppos, qpos, k) {
  ## If there are too few hypotheses, `combinations` can crash R!
  stopifnot(qpos[1] - qpos[k] >= k - 1)

  pstore <- Inf
  qstore <- rep(-Inf, k)

  getc <- function(y) {
    combs <- qpos[k] + which(y)
    ## Check that this particular combination satisfies the upper
    ## bounds; proceed if it does
    if (all(sapply(seq_len(k-1), function(j) {
      sum(combs > qpos[j]) < j
    }))) {
      i <- c(seq.int(ppos, qpos[k]), combs)
      ptemp <- qmin(i)
      qtemp <- qmaxk(i)
      ## If ptemp is smaller than any of the previous possibilities,
      ## store it
      if (ptemp < pstore) {
        pstore <<- ptemp
      }
      ## If an element of qtemp is larger than any of the previous
      ## possibilities, store it
      if (any(qtemp > qstore)) {
        qstore <<- pmax(qtemp, qstore)
      }
    }
    NULL
  }

  .null <- combinations(qpos[1] - qpos[k], k-1, getc)
  return(c(pstore, qstore))
}
