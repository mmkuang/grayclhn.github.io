### Copyright (c) 2011-2013 Gray Calhoun.

### This program is free software: you can redistribute it and/or 
### modify it under the terms of the GNU General Public License as 
### published by the Free Software Foundation, either version 3 of 
### the License, or (at your option) any later version.

### This program is distributed in the hope that it will be useful,
### but WITHOUT ANY WARRANTY; without even the implied warranty of 
### MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
### GNU General Public License for more details.

### You should have received a copy of the GNU General Public License 
### along with this program. If not, see 
### <http://www.gnu.org/licenses/>.

rdgp <- function(type, nobs) {
  if (type %in% 2:7) {
    mu <- switch(type - 1, rep(1, 40), c(rep(1.4, 6), rep(1, 34)),
                 c(rep(1.4, 6), rep(-1, 34)), c(rep(1.4, 20), rep(1, 20)),
                 c(rep(1.4, 20), rep(-1, 20)), rep(1.4, 40))
    return(list(y = rnorm(nobs, 1, 1),
                x = mvrnorm(nobs, mu, diag(rep(c(1, 2), 20)))))
  } else if (type == 1) {
    y <- rnorm(nobs, 1, 1)
    w <- rnorm(nobs, 0, 1)
    return(list(y = y, x = cbind(y + w, y - w)))
  } else if (type > 7) {
    mu <- switch(type - 7,
                 rep(1, 4),
                 c(rep(1.4, 2), rep(1, 2)),
                 c(rep(1.4, 2), rep(-1, 2)))
    return(list(y = rnorm(nobs, 1, 1),
                x = mvrnorm(nobs, mu, diag(4))))
  }
}

check.rejections <- function(stat, crit, type, method) {
  rejections <- stat > crit
  falseCount <- switch(type, 0, 0, 34, 34, 20, 20, 40, 0, 2, 2)
  if (method %in% c("RW1", "ours1", "SPA", "Bon")) {
    ## Check 1-FWE or size
    truehyp <- falseCount + seq_len(length(rejections) - falseCount)
    iserror <- any(rejections[truehyp])
    ncorrect <- sum(rejections[seq_len(falseCount)])
  } else if (method %in% c("RWk", "oursk")) {
    ## Check k-FWE for k = 3
    truehyp <- falseCount + seq_len(length(rejections) - falseCount)
    iserror <- sum(rejections[truehyp]) >= 3
    ncorrect <- sum(rejections[seq_len(falseCount)])
  } else {
    ## Use Andrews & Barwick's statistic (based on only one stat)
    iserror <- unname(falseCount == 0 && rejections)
    ncorrect <- unname((falseCount > 0) && rejections)
  }
  c(ncorrect = ncorrect, error = iserror)
}

stepmwrapper <- function(tstats, tstats.boot, method, level, nobs) {
  switch(method,
         RW1 = stepm(tstats, tstats.boot, level),
         ours1 = stepm(tstats, tstats.boot, level, lcut = TRUE),
         SPA = stepm(tstats, tstats.boot, level, lcut = - sqrt(2 * log(log(nobs)))),
         Bon = bonftest(tstats, tstats.boot, level),
         RWk = stepm(tstats, tstats.boot, level, k = 3),
         oursk = stepm(tstats, tstats.boot, level, k = 3, lcut = TRUE, rcut = TRUE))[2]
}
         
dotests <- function(dmat, simtype, level, nboot, matlab = NULL,...) {

  get_tstats <- function(x)
    sqrt(nrow(x)) * apply(x, 2, function(y) mean(y) / sd(y))

  tstats <- get_tstats(dmat)
  dDemeaned <- t(t(dmat) - colMeans(dmat))
  nobs <- nrow(dmat)
  tstats.boot <- RepParallel(nboot, {
    dboot <- dDemeaned[sample(seq.int(nobs), nobs, replace = TRUE),]
    get_tstats(dboot)
  })

  if (simtype == 1) {
    stepms <- c("RW1", "ours1", "SPA", "Bon")
    doAQLR <- nobs == 100
  } else if (simtype %in% 2:7) {
    stepms <- c("RW1", "ours1", "SPA", "Bon", "RWk", "oursk")
    doAQLR <- FALSE
  } else {
    stepms <- c("ours1", "SPA", "Bon")
    doAQLR <- nobs == 100
  }

  results <-
    data.frame(stat = stepms, row.names = NULL,
      t(sapply(stepms, function(s) {
        check.rejections(tstats, stepmwrapper(tstats, tstats.boot, s, level, nobs),
                         simtype, s)
      })))
  
  if (doAQLR) {
    andrewsbarwick <- AQLR(dmat, matlab, level)
    results <- rbind(results, data.frame(stat = "AQLR",
      as.list(check.rejections(andrewsbarwick["stat"],
                               andrewsbarwick["crit"], simtype, "AQLR"))))
  }
  return(results)                
}
