%{
RE Andrews and Barwick (2012) paper:

The following procedure is used by rmsprg_final.m /
rmsprg_fs_short_final.m and computes KAPPA and ETA-AUTO based on a
given value of DELTA and a rule (that is programmed into the code) for
how KAPPA and ETA-AUTO should depend on DELTA.  DELTA is a measure of
how much correlation is in the correlation matrix OMEGA, which
corresponds to the variance matrix V.

The following KAPPA values were determined by maximizing avg power
over KAPPA for the case of P = 2 using program kappaprg. Done on Jan
21/11. The KAPPA values for DELTA <=-.85 are not the ones that yield
maximum avg power for P=2. They have been taken to be larger than
those values because this improves size properties for P>2, only
sacrifices a little power for P=2, and sacrifices no power for
P>2. The results for P=2 were computed using this program,
kappaprg_final, with 200,000 simulation repetitions by the method
described at the beginning of this program the results for P>=3 were
computed using programs etaprg1_final and etaprg2_final with 40,000
simulation repetitions.
%}

function[KAPPA, ETAAUTO] = AUTOMAT(DELTA,P)

      if DELTA < -.975;
            KAPPA = 2.9; ETAAUTO = .025;
         elseif DELTA >= -.975 && DELTA < -.95;
            KAPPA = 2.9; ETAAUTO = .026;
         elseif DELTA >= -.95 && DELTA < -.90;
            KAPPA = 2.9; ETAAUTO = .021;
         elseif DELTA >= -.90 && DELTA < -.85;
            KAPPA = 2.8; ETAAUTO = .027;
         elseif DELTA >= -.85 && DELTA < -.80;
            KAPPA = 2.7; ETAAUTO = .062;
         elseif DELTA >= -.80 && DELTA < -.75;
            KAPPA = 2.6; ETAAUTO = .104;    
         elseif DELTA >= -.75 && DELTA < -.70;
            KAPPA = 2.6; ETAAUTO = .103;
         elseif DELTA >= -.70 && DELTA < -.65;
            KAPPA = 2.5; ETAAUTO = .131;
         elseif DELTA >= -.65 && DELTA < -.60;
            KAPPA = 2.5; ETAAUTO = .122;
         elseif DELTA >= -.60 && DELTA < -.55;
            KAPPA = 2.5; ETAAUTO = .113;
         elseif DELTA >= -.55 && DELTA < -.50;
            KAPPA = 2.5; ETAAUTO = .104;
         elseif DELTA >= -.50 && DELTA < -.45;
            KAPPA = 2.4; ETAAUTO = .124;
         elseif DELTA >= -.45 && DELTA < -.40;
            KAPPA = 2.2; ETAAUTO = .158;
         elseif DELTA >= -.40 && DELTA < -.35;
            KAPPA = 2.2; ETAAUTO = .133;
         elseif DELTA >= -.35 && DELTA < -.30;
            KAPPA = 2.1; ETAAUTO = .138;
         elseif DELTA >= -.30 && DELTA < -.25;
            KAPPA = 2.1; ETAAUTO = .111;
         elseif DELTA >= -.25 && DELTA < -.20;
            KAPPA = 2.1; ETAAUTO = .082;
         elseif DELTA >= -.20 && DELTA < -.15;
            KAPPA = 2.0; ETAAUTO = .083;
         elseif DELTA >= -.15 && DELTA < -.10;
            KAPPA = 2.0; ETAAUTO = .074;
         elseif DELTA >= -.10 && DELTA < -.05;
            KAPPA = 1.9; ETAAUTO = .082;
         elseif DELTA >= -.05 && DELTA < 0.00;
            KAPPA = 1.8; ETAAUTO = .075;
         elseif DELTA >= 0.00 && DELTA < 0.05;
            KAPPA = 1.5; ETAAUTO = .114;
         elseif DELTA >= 0.05 && DELTA < 0.10;
            KAPPA = 1.4; ETAAUTO = .112;
         elseif DELTA >= 0.10 && DELTA < 0.15;
            KAPPA = 1.4; ETAAUTO = .083;
         elseif DELTA >= 0.15 && DELTA < 0.20;
            KAPPA = 1.3; ETAAUTO = .089;
         elseif DELTA >= 0.20 && DELTA < 0.25;
            KAPPA = 1.3; ETAAUTO = .058;
         elseif DELTA >= 0.25 && DELTA < 0.30;
            KAPPA = 1.2; ETAAUTO = .055;
         elseif DELTA >= 0.30 && DELTA < 0.35;
            KAPPA = 1.1; ETAAUTO = .044;
         elseif DELTA >= 0.35 && DELTA < 0.40;
            KAPPA = 1.0; ETAAUTO = .040;
         elseif DELTA >= 0.40 && DELTA < 0.45;
            KAPPA = 0.8; ETAAUTO = .051;
         elseif DELTA >= 0.45 && DELTA < 0.50;
            KAPPA = 0.8; ETAAUTO = .023;
         elseif DELTA >= 0.50 && DELTA < 0.55;
            KAPPA = 0.6; ETAAUTO = .033;
         elseif DELTA >= 0.55 && DELTA < 0.60;
            KAPPA = 0.6; ETAAUTO = .013;
         elseif DELTA >= 0.60 && DELTA < 0.65;
            KAPPA = 0.4; ETAAUTO = .016;
         elseif DELTA >= 0.65 && DELTA < 0.70;
            KAPPA = 0.4; ETAAUTO = .000;
         elseif DELTA >= 0.70 && DELTA < 0.75;
            KAPPA = 0.2; ETAAUTO = .003;
         elseif DELTA >= 0.75 && DELTA < 0.80;
            KAPPA = 0.0; ETAAUTO = .002;
         elseif DELTA >= 0.80 && DELTA < 0.85;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.85 && DELTA < 0.90;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.90 && DELTA < 0.95;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.95 && DELTA < 0.975;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.975 && DELTA < 0.99;
            KAPPA = 0.0; ETAAUTO = .000;
         elseif DELTA >= 0.99;       
            KAPPA = 0.0; ETAAUTO = .000;
      end;

% The AUTOETA values above have been determined for P==2. For P >= 3,
% we have to increase them all by the amount indicated.

          if P == 3;
            ETAAUTO = ETAAUTO + .15;
         elseif P == 4;
            ETAAUTO = ETAAUTO + .17;
         elseif P == 5;
            ETAAUTO = ETAAUTO + .24;
         elseif P == 6;
            ETAAUTO = ETAAUTO + .31;
         elseif P == 7;
            ETAAUTO = ETAAUTO + .33;
         elseif P == 8;
            ETAAUTO = ETAAUTO + .37;
         elseif P == 9;
            ETAAUTO = ETAAUTO + .45;
         elseif P == 10;
            ETAAUTO = ETAAUTO + .50;
         end;
