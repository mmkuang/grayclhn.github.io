%{
  January 31/07;  Revised May 21/07; Revised April 19/09; Revised May 6/2011

                  REFINED GENERALIZED MOMENT SELECTION (RGMS) PROCEDURES

      THIS PROGRAM IS CONCERNED WITH TESTS OF MULTIVARIATE ONE-SIDED HYPOTHESES for 
      USE IN TESTS and CONFIDENCE INTERVALS CONCERNING MOMENT INEQUALITIES. 
      
      ANDREWS AND BARWICK (2012). THIS PROGRAM COMPUTES RESULTS FOR THE
      MMM (I.E., SUM) AND AQLR TEST STATISTICS AND THE PA, t-TEST/KappaAuto/Nm, AND 
      t-TEST/KappaAuto/Bt CRITICAL VALUES. THE RECOMMENDED TEST IN ANDREWS AND JIA (2011) IS 
      THE AQLR/t-TEST/KappaAuto/Bt test. THE MMM/PA TEST IS FASTER TO COMPUTE AND MAY BE USEFUL
      FOR DETERMINING THE ROUGH SHAPE OF A CONFIDENCE INTERVAL BEFORE SWITCHING TO THE 
      RECOMMENDED TEST FOR GETTING MORE PRECISE RESULTS.

      TESTING PROBLEM CONSIDERED HERE:      

                        H_0: MU>=0      VERSUS     H_1: MU NOT >=0. 
 %}   
       
clc
clear
format short g

s = RandStream.create('mt19937ar','seed',5489);
RandStream.setDefaultStream(s);     %Set the random generator

% ENTER THE NUMBER OF BLOCKS USED IN MONTE CARLO SIMULATION OF CRITICAL VALUES. 
% FOR 40,000 REPS USE 40.  FOR 5,000 REPS USE 5.
    NUMR1 = 10;   
    
% SPECIFY THE LENGTH OF BLOCKS USED IN MONTE CARLO SIMULATION OF CRITICAL VALUES.
% NOTE THAT THE TOTAL NUMBER OF OBSERVATIONS USED TO SIMULATE DATA-DEPENDENT 
% QUANTILES IS NUMR1 * R1. TYPICALLY THIS IS 1000.
    R1 = 1000; 
    
% ENTER THE DESIRED SIGNIFICANCE LEVEL. THIS MUST BE .05 IF THE RECOMMENDED TEST OF
% ANDREWS AND JIA (2011) IS TO BE USED.
    SIGLEVEL = .05;
    
% ENTER THE N BY P MATRIX, XMAT, OF SAMPLE MOMENTS, WHERE N IS THE SAMPLE SIZE AND 
% P IS THE NUMBER OF MOMENT INEQUALITIES. THE i'TH ROW OF XMAT IS THE P VECTOR OF
% SAMPLE MOMENT FUNCTIONS EVALUATED AT THE NULL HYPOTHESIS VALUE THETA0. THAT IS,
% IT EQUALS m(W_i,THETA0), WHERE W_i IS THE DATA VECTOR FOR THE i'TH OBSERVATION IN
% THE SAMPLE. FOR THE RECOMMENDED TEST MUST HAVE P<=10.  
    % XMAT = ??. 
    
% TO DEMONSTRATE HOW THE PROGRAM WORKS, WE NOW RANDOMLY GENERATE A DATA MATRIX, 
% XMAT. THE FOLLOWING LINES SHOULD BE BLOCKED OUT OR DELETED WHEN USING THIS PROGRAM
% WITH A REAL DATA SET XMAT. ALSO, THE LINES IN THE PRINT STATEMENTS
% REFERRING TO THE TRUE MU AND V SHOULD ALSO BE COMMENTED OUT.
 
    N = 100;     		% N IS THE SAMPLE SIZE. 
    P = 3;          	% P IS THE NUMBER OF MOMENT INEQUALITIES.
    B = normrnd(0,1,P,P);
    V = B*B';  
    STACK = sqrt(diag(V));
    V = V ./ (STACK * STACK');
                        % V IS DEFINED TO HAVE ONES ON THE DIAGONAL.
                        % /* V=EYE(P); */
    VSQRT = sqrtm(V);	% V CANT BE SINGULAR
    MU = [-.0;-.0;-.0];    
    XMAT = normrnd(0,1,N,P)*VSQRT + ones( N, 1)*MU';
    
% ENTER THE TESTS THAT ARE TO BE COMPUTED.  

% THE AQLR_tTEST_KAUTO_BT TEST IS THE RECOMMENDED TEST IN ANDREWS AND JIA (2011).
% IT USES THE RMS CRITICAL VALUE COMPUTED USING THE BOOTSTRAP AND USES AN 
% AUTOMATIC KAPPA VALUE.  
% SET THE FOLLOWING VARIABLE EQUAL TO 1 TO COMPUTE THIS TEST, 0 OTHERWISE.  
    COMPUTE_AQLR_tTEST_KAUTO_BT = 1;

% THE AQLR_tTEST_KAUTO_Nm TEST USES THE AUTOMATIC KAPPA VALUE FROM ANDREWS AND JIA (2011)
% COMBINED WITH THE ASY NORMAL VERSION OF THE CRIT VAL, NOT THE BOOTSTRAP. 
    COMPUTE_AQLR_tTEST_KAUTO_Nm = 1;

% THE MMM_tTEST_K235_Nm TEST IS VERY FAST TO COMPUTE. IT IS A GOOD CHOICE TO MAP OUT
% A CONFIDENCE SET CRUDELY. THEN, IT CAN BE DETERMINED MORE PRECISELY USING THE RECOMMENDED
% TEST. 
    COMPUTE_MMM_tTEST_K235_Nm = 1;

% THE AQLR_PA_Nm TEST USES THE PA CRITICAL VALUE (I.E., THE LEAST FAVORABLE CV).
% IT IS NOT A RECOMMENDED TEST, BUT IT IS FAST TO COMPUTE. 
    COMPUTE_AQLR_PA_Nm = 1;

% THE MMM_PA_Nm TEST USES THE PA CRITICAL VALUE (I.E., THE LEAST FAVORABLE CV).
% IT IS NOT A RECOMMENDED TEST, BUT IT IS FAST TO COMPUTE.  */
    COMPUTE_MMM_PA_Nm = 1;

% THIS IS THE END OF THE INPUTS TO THE PROGRAM. 


% START THE PROGRAM. 

% COMPUTE THE VECTOR OF SAMPLE MEANS (TIMES SQRT(N)) AND SAMPLE VARIANCE MATRIX
% OF THE MOMENTS. 
    [N P]= size( XMAT );
    XBAR = sqrt( N ) * mean( XMAT )';       %  XBAR IS A P BY 1 VECTOR.
    VHAT = cov( XMAT );

%{  
  TO SPECIFY THE TEST STATISTIC AND CRITICAL VALUE DESIRED, WE USE THE VARIABLES
  STATTYPE and CVTYPE BELOW.  
      STATTYPE==1   for MMM, I.E.SUM, TEST.
      STATTYPE==2.5 for ADJUSTED QLR TEST. THIS TEST ALWAYS USES A PD WEIGHT MATRIX EVEN if VAR 
                    MATRIX IS SINGULAR. IT ADDS MAX{ .01-DET(OMEGA), 0}*DIAG( V ) TO THE V 
                    MATRIX, WHERE OMEGA IS THE CORRELATION MATRIX THAT CORRESPONDS TO THE V 
                    MATRIX.
      CVTYPE==0     for STD PLUG-IN ASYMPTOTIC (PA) CRIT VALUE, 
      CVTYPE==1     for PHI1, I.E., t TEST, CRIT VALUE. NEED TO SPECIFY KAPPA for THIS CV,
      CVTYPE==11    for t TEST CRIT VALUE WITH AUTOMATIC DETERMINATION OF KAPPA and
                    ETA BASED ON V THROUGH DELTA(OMEGA), WHERE OMEGA IS THE CORR
                    MATRIX THAT CORRESPONDS TO V.

      CVTYPE == 100   BOOTSTRAP PLUG-IN ASY CRIT VAL,
      CVTYPE == 101   BOOTSTRAP PHI1, t TEST, (A CONDITIONAL CV), NEED TO SPECIFY KAPPA WITH
                      THIS CV,
      CVTYPE == 1011  BOOTSTRAP PHI1, t TEST, WITH AUTOMATIC DETERMINATION OF KAPPA 
                      and ETA BASED ON V. 
%}


% NOW COMPUTE THE AQLR_tTEST_KAUTO_BT TEST. THIS IS THE RECOMMENDED TEST IN
% ANDREWS AND JIA (2011).
    if COMPUTE_AQLR_tTEST_KAUTO_BT==1;
       STATTYPE=2.5;
       CVTYPE=1011;
       KAPPA=0;
       STAT_AQLR = STAT( XBAR', VHAT, STATTYPE );
       CV_AQLR_tTEST_KAUTO_BT = CRITVALS( XBAR, VHAT, XMAT, STATTYPE, CVTYPE,...
                                          KAPPA, SIGLEVEL, R1, NUMR1);
       TEST_AQLR_tTEST_KAUTO_BT = (STAT_AQLR>CV_AQLR_tTEST_KAUTO_BT);
    end;


% COMPUTE THE AQLR_tTEST_KAUTO_Nm TEST. THIS IS THE ASY NORMAL VERSION OF THE 
% RECOMMENDED TEST IN ANDREWS and JIA (2011).  
    if COMPUTE_AQLR_tTEST_KAUTO_Nm==1;
       STATTYPE=2.5;
       CVTYPE=11;
       KAPPA=0;
       STAT_AQLR = STAT( XBAR', VHAT, STATTYPE );
       CV_AQLR_tTEST_KAUTO_Nm = CRITVALS( XBAR, VHAT, XMAT, STATTYPE, CVTYPE,...
                                          KAPPA, SIGLEVEL, R1, NUMR1);
       TEST_AQLR_tTEST_KAUTO_Nm = (STAT_AQLR>CV_AQLR_tTEST_KAUTO_Nm);
    end;

% COMPUTE THE MMM_tTEST_Nm TEST WITH KAPPA = 2.35.  
    if COMPUTE_MMM_tTEST_K235_Nm==1;   
       STATTYPE=1;
       CVTYPE=1;
       KAPPA=2.35;
       STAT_MMM = STAT( XBAR', VHAT, STATTYPE );
       CV_MMM_tTEST_K235_Nm = CRITVALS( XBAR, VHAT, XMAT, STATTYPE, CVTYPE,...
                                    KAPPA, SIGLEVEL, R1, NUMR1);
       TEST_MMM_tTEST_K235_Nm = (STAT_MMM>CV_MMM_tTEST_K235_Nm);
    end;

% COMPUTE THE AQLR_PA_Nm TEST.  
    if COMPUTE_AQLR_PA_Nm==1;   
       STATTYPE=2.5;
       CVTYPE=0;
       KAPPA=0;
       STAT_AQLR = STAT( XBAR', VHAT, STATTYPE );
       CV_AQLR_PA_Nm = CRITVALS( zeros(P,1), VHAT, zeros(N, P), STATTYPE, CVTYPE,...
                              KAPPA, SIGLEVEL, R1, NUMR1);
       TEST_AQLR_PA_Nm = (STAT_AQLR>CV_AQLR_PA_Nm);
    end;

% COMPUTE THE MMM_PA_Nm TEST.
    if COMPUTE_MMM_PA_Nm==1;   
       STATTYPE=1;
       CVTYPE=0;
       KAPPA=0;
       STAT_MMM = STAT( XBAR', VHAT, STATTYPE );
       CV_MMM_PA_Nm = CRITVALS( zeros(P,1), VHAT, zeros(N, P), STATTYPE, CVTYPE,...
                             KAPPA, SIGLEVEL, R1, NUMR1);
       TEST_MMM_PA_Nm = (STAT_MMM>CV_MMM_PA_Nm);
    end;
    
% PRINT RESULTS
    DATE1=date;
    % SPECIFY THE OUTPUT FILE
    fid=fopen('.\RMSPRG_OUTPUT.txt', 'w');
    fprintf(fid,'*************************************************************************\r\n');
    fprintf(fid,'*************************************************************************\r\n');
    fprintf(fid, DATE1);
    fprintf(fid, '\r\n');
    fprintf(fid, 'THIS IS OUTPUT FROM PROGRAM: rmsprg_final.\r\n');
    fprintf(fid, '\r\n');
    fprintf(fid, 'REFINED MOMENT SELECTION TEST OF ANDREWS AND JIA (2011)\r\n');
    fprintf(fid, '            FOR MULTIVARIATE ONE-SIDED TESTS\r\n');
    fprintf(fid, '            FOR MOMENT INEQUALITY PROBLEMS\r\n');
    fprintf(fid, '\r\n');
    fprintf(fid, 'SAMPLE SIZE N IS %4.0f\r\n',  N);
    fprintf(fid, 'NUMBER OF MOMENT INEQUALITIES P IS %2.0f\r\n',  P);
    fprintf(fid, 'NUMBER OF CRIT VAL REPETITIONS IS %8.0f\r\n',  NUMR1*R1);   
    fprintf(fid, '\r\n');
    
    if COMPUTE_AQLR_tTEST_KAUTO_BT== 1;
       fprintf(fid,'RECOMMENDED TEST OF ANDREWS AND JIA (2011):\r\n');
       if TEST_AQLR_tTEST_KAUTO_BT==1;
             fprintf(fid,'AQLR_tTEST_KAUTO_BT TEST:  REJECTS H0.\r\n');
       else
             fprintf(fid,'AQLR_tTEST_KAUTO_BT TEST:  FAILS TO REJECT H0.\r\n');
       end;
       fprintf(fid, '\r\n');
    end;
    
    if COMPUTE_AQLR_tTEST_KAUTO_Nm==1||COMPUTE_MMM_tTEST_K235_Nm==1||... 
       COMPUTE_AQLR_PA_Nm==1||COMPUTE_MMM_PA_Nm==1;
       fprintf(fid,'OTHER TESTS:\r\n');
    end;
    if COMPUTE_AQLR_tTEST_KAUTO_Nm==1;
       if TEST_AQLR_tTEST_KAUTO_Nm==1;
             fprintf(fid,'AQLR_tTEST_KAUTO_Nm TEST:  REJECTS H0.\r\n');
       else
             fprintf(fid,'AQLR_tTEST_KAUTO_Nm TEST:  FAILS TO REJECT H0.\r\n');
       end;
       fprintf(fid, '\r\n');
    end;
    
    if COMPUTE_MMM_tTEST_K235_Nm==1;
       if TEST_MMM_tTEST_K235_Nm==1;
             fprintf(fid,'MMM_tTEST_K235_Nm TEST:    REJECTS H0.\r\n');
       else
             fprintf(fid,'MMM_tTEST_K235_Nm TEST:    FAILS TO REJECT H0.\r\n');
       end;
       fprintf(fid, '\r\n');
    end;
    
    if COMPUTE_AQLR_PA_Nm==1;
       if TEST_AQLR_PA_Nm==1;
             fprintf(fid,'AQLR_PA_Nm TEST:           REJECTS H0.\r\n');
       else
             fprintf(fid,'AQLR_PA_Nm TEST:           FAILS TO REJECT H0.\r\n');
       end;
       fprintf(fid, '\r\n');
     end;
     
    if COMPUTE_MMM_PA_Nm==1;
       if TEST_MMM_PA_Nm==1;
             fprintf(fid,'MMM_PA_Nm TEST:            REJECTS H0.\r\n');
       else
             fprintf(fid,'MMM_PA_Nm TEST:            FAILS TO REJECT H0.\r\n');
       end;
       fprintf(fid, '\r\n');
    end;
  
    fprintf(fid,'TRUE V MATRIX = \r\n'); % COMMENT OUT THESE LINES 
    for i=1:size(V,1);					 % WHEN USING REAL DATA
       fprintf(fid,'%6.2f',V(i,:));	     % COMMENT OUT THESE LINES
       fprintf(fid, '\r\n');			 % WHEN USING REAL DATA
    end							         % COMMENT OUT THESE LINES WHEN USING REAL DATA
    
    fprintf(fid,'ESTIMATED V MATRIX = \r\n');
    for i=1:size(VHAT,1);
       fprintf(fid,'%6.2f',VHAT(i,:));
       fprintf(fid, '\r\n');
    end
    fprintf(fid, '\r\n');
    fprintf(fid,'TRUE MEAN VECTOR = \r\n'); % COMMENT OUT THESE LINES
    fprintf(fid,'%6.2f\r\n',  MU);          % WHEN USING REAL DATA 
    fprintf(fid,'SQRT(N)*SAMPLE MEAN OF MOMENTS = \r\n');
    fprintf(fid,'%6.2f\r\n',  XBAR);
    fprintf(fid, '\r\n');
    fprintf(fid,'STAT_AQLR= %10.4f\r\n',  STAT_AQLR);
    fprintf(fid,'STAT_MMM= %10.4f\r\n',  STAT_MMM);
    fprintf(fid, '\r\n');
    fprintf(fid,'CV_AQLR_tTEST_KAUTO_BT= %10.4f\r\n',  CV_AQLR_tTEST_KAUTO_BT);
    fprintf(fid,'CV_AQLR_tTEST_KAUTO_Nm= %10.4f\r\n',  CV_AQLR_tTEST_KAUTO_Nm);
    fprintf(fid,'CV_AQLR_PA_Nm=          %10.4f\r\n',  CV_AQLR_PA_Nm);
    fprintf(fid,'CV_MMM_tTEST_K235_Nm=   %10.4f\r\n',  CV_MMM_tTEST_K235_Nm);
    fprintf(fid,'CV_MMM_PA_Nm=           %10.4f\r\n',  CV_MMM_PA_Nm);
    fprintf(fid, '\r\n');
    fprintf(fid, '\r\n');
    fprintf(fid,'*************************************************************************\r\n');
    fprintf(fid,'*************************************************************************\r\n');
    fclose(fid);
 

  


    
    



    
    
    
    