% RE ANDREWS AND BARWICK (2012) PAPER:
% THIS IS USED BY FILES rmsprg_final.m / rmsprg_fs_short_final.m AND TAKES A R BY P 
% MATRIX OF DATA, ZMAT, AND A P BY P VARIANCE MATRIX, V, AND COMPUTES AN R VECTOR 
% OF TEST STATISTICS. THE TYPE OF TEST STATISTIC THAT IS CALCULATED IS SPECIFIED BY STATTYPE. 
% WHEN ONE IS COMPUTING A SINGLE TEST STATISTIC, R=1. WHEN THE CRITICAL VALUE 
% PROCEDURE, CRITVALS, CALLS THE STAT(.) PROCEDURE, IT COMPUTES R TEST STATISTIC
% AT A TIME, WHERE R IS RELATED TO THE NUMBER OF SIMULATION REPETITIONS.

%         STATTYPE==1   for MMM, I.E.SUM, TEST. THIS IS FUNCTION S_1.
%         STATTYPE==2.5 for AQLR TEST. THIS IS FUNCTION S_2.5. IT USES AN ADJUSTED WEIGHT 
%                       MATRIX THAT IS GUARANTEED TO BE PD EVEN if V IS NOT PD. THE 
%                       ADJUSTMENT DEPENDS ON A POSITIVE CONSTANT EPSILON=.012.  */

function[ STATVEC ] = STAT( ZMAT, V, STATTYPE )

 options = optimset('Algorithm', 'active-set', 'display', 'off');
 warning off optim:quadprog:HessianNotSym

 [R P]=size(ZMAT);         
 VINVER = pinv( V );
 DIAGV = diag( V );                 
 
 % INITIALIZE THE QUADRATIC PROGRAMMING PROBLEM
 START = zeros(P,1); % THESE ARE STARTING VALUES.
 UPBD = Inf;	% THIS IS AN UPPER BOUND ON THE ELEMENTS OF THE 
                % SOLUTION VECTOR.
 A = []; 		% THIS MEANS THERE ARE NO EQUALITY CONSTRAINTS.  
 B = []; 		% THIS MEANS THERE ARE NO EQUALITY CONSTRAINTS.    
 C = eye(P); 	% THIS MEANS THE INEQUALITY CONSTRAINTS 
                            % ARE ELEMENT BY ELEMENT. 
 D = zeros(P,1);  % THIS MEANS THE LOWER BOUNDS ON THE 
                            % INEQUALITIES ARE ZERO.  */ 
 LBNDS = zeros(P,1);
 UBNDS = UPBD*ones(P,1);
 
 % FOR SINGULAR MATRIX
 STACK = sqrt(diag(V));
 VC = V ./ (STACK * STACK');
 EPSILON = .012;
 if EPSILON-det(VC)>0;
       VINVER = pinv( V + (EPSILON-det(VC)) * diag(diag(V)) );
 end;

 if STATTYPE == 1;
	   STACK = repmat(sqrt(DIAGV'),R,1); 
	   ZMAT = ZMAT ./ STACK ;               
	   STATVEC = sum( (ZMAT.*( ZMAT<=0 )).^2, 2);
 elseif STATTYPE == 2.5;
	   STATVEC = zeros(R, 1);
	   for JJ=1:R;
		  SOLN = quadprog(VINVER,-VINVER * ZMAT(JJ,:)',-C,-D,A,B,LBNDS,UBNDS,START,options);
		  STATVEC(JJ) = (ZMAT(JJ,:)'-SOLN)'*VINVER*(ZMAT(JJ,:)'-SOLN);
	   end;
 end;

    