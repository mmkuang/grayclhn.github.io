set.seed(209)
nsim <- 5000
require(ftestLargeK)
require(lmtest)
require(sandwich)

re2 <- function(n) rexp(n) - 1

mcdesign <- expand.grid(n = c(100, 200, 500),
                        x = c("norm", "cauchy"),
                        e = c("rt", "re2"),
                        edf = c(5, 30),
                        k = c(.1, .25, .5),
                        nrest = c("1", "k/2", "k-1"), stringsAsFactors = FALSE)
mcdesign$edf <- ifelse(mcdesign$e != "rt", NA, mcdesign$edf)
mcdesign <- unique(mcdesign)
row.names(mcdesign) <- seq_along(mcdesign$n)

rpval <- function(n, rx, px, re, k, nrst, het = FALSE) {
  x <- cbind(1, matrix(rx(n * (k-1)), n, k-1))
  y <- if(het) {
    re(n) * (1 + px(x[,2]))
  } else re(n)
  stats <- AllStats(y, X.null = x[,1:(k-nrst), drop = FALSE], X.alt = x)

  d <- data.frame(y, x)
  mfull <- lm(formula(paste("y ~ ", paste(paste("X", 1:3, sep = ""), collapse = " + "), "-1")), d)
  mrest <- lm(formula(paste("y ~ ", paste(paste("X", 1:2, sep = ""), collapse = " + "), "-1")), d)

  wald <- if(het) {
    waldtest(mfull, mrest, vcov = vcovHC, test = "Chisq")[2,4]
  } else {
    pchisq(nrst*stats[1], nrst, lower.tail = FALSE)
  }
  
  c("F"    = pf(stats[1], nrst, n - k, lower.tail = FALSE), 
    "Ghat" = pf(stats[2], nrst, n - k, lower.tail = FALSE),
    "GEasy" = pf(stats[3], nrst, n - k, lower.tail = FALSE),
    "N"    = pnorm(stats[4], lower.tail = FALSE),          
    "Wald" = wald)
}                    

## basic monte carlo
domc <- function(mcdesign, nsim, het = FALSE, size = 0.05) {
  do.call(rbind, lapply(seq_along(mcdesign$n), function(i) {
    simavg <- rowMeans(with(mcdesign[i,], replicate(nsim, {
      rx <- eval(parse(text = paste("r", x, sep = "")))
      px <- eval(parse(text = paste("p", x, sep = "")))
      re <- eval(parse(text = if (is.na(edf)) {e} else {paste("function(n)", e, "(n,", edf, ")")}))
      k <- n * k
      nrst <- eval(parse(text = nrest))
      rpval(n, rx, px, re, k, nrst, het)
    })) < size)
    data.frame(mcdesign[i,], stat = names(simavg), r.prob = simavg, row.names = seq_along(simavg))
}))}

## homoskedastic monte carlo
mc.hom <- domc(mcdesign, nsim, FALSE)
## heteroskedastic monte carlo
mc.het <- domc(mcdesign, nsim, TRUE)

save(mc.hom, mc.het, file = "mc/makesizetable.Rdata")
