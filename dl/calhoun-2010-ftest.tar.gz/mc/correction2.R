dFtrue <- function(x, adjust, n, k, m) {
	c1 <- 2 * (1 + m/(n-k))
	v  <- sqrt(c1 / (c1 + adjust))
	v * df(x * v + (1-v), m, n-k)
}

truesize <- function(nomsize, adjust, n, k, m) {
	integrate(function(x) dFtrue(x, adjust, n, k, m), 
		qf(1 - nomsize, m, n-k), Inf)$value
}

nvec   <- c(100, 500)
kratio <- c(0.10, 0.50)
adjusts <- seq(-1,3,0.05)
sizevec <- c(0.01, 0.05, 0.10)

sizedata <- rep(NA, length(nvec) * length(kratio) * 3 * length(adjusts)
	* length(sizevec))

j <- 0
for (n in nvec) {
  for (k in ceiling(n * kratio)) {
    for (m in c(1, ceiling(k/2), k-1)) {
      for (s in sizevec) {
        for (adj in adjusts) {
          if (m > k) {
            sizedata[j <- j+1] <- NA
          } else {
            sizedata[j <- j+1] <- truesize(s, adj, n, k, m)
          }
	}
      }
    }
  }
}

library(lattice)
ltheme <- canonical.theme(color = FALSE)
ltheme$strip.background$col <- "transparent"
lattice.options(default.theme = ltheme)

sizeframe <- data.frame(sizedata,
	expand.grid(adjusts, sizevec, c("q = 1", "q = k/2", "q = k - 1"),
                  c("k=n/10", "k=n/2"), nvec))
colnames(sizeframe) <- c("size", "adjust", "nomsize", "qratio", "kratio", "n")

pdf(file = "graphs/sizePlot.pdf", height = 4.5, width = 6.5)
print(xyplot(data = sizeframe, 
             size ~ adjust | qratio + kratio, groups = interaction(n, nomsize), lty = c(1,2),,
             key = simpleKey(text = c("n = 100", "n = 500"), points = FALSE, lines = TRUE, space = "bottom", columns = 2),
             type = "l", ylim = c(0,0.25),
             xlab = expression(kappa %.% bar(D)),
             main = ""))
dev.off()

n <- 50
k <- 20
m <- 10
c1 <- 2 * (1+m/(n-k))
adj <- c1/(.75)^2 - c1
xseq <- seq(from = -.25, to = 4, length = 600)
pdf("graphs/densityPlot.pdf", height = 3, width = 3)
par(mai = c(0.5, 0.5, 0, 0))
plot(c(xseq, xseq), c(dFtrue(xseq, adj, n, k, m), 
	df(xseq, m, n-k)), type = "n", las = 1, ylab = "f(x)", xlab = "x")
xx <- c(seq(qf(0.9, m, n-k), 4, 0.01), 3.979568, qf(0.9, m, n-k))
yy <- c(dFtrue(seq(qf(0.9, m, n-k), 4, 0.01), adj, n, k, m), 0, 0)
polygon(xx, yy, col = "gray", border = NA)
curve(dFtrue(x, adj, n, k, m), -1, 4, 600, add = T, col = "black")
curve(df(x, m, n-k), -1, 4, 600, add = T, col = "black", lty = "dotted",
	lwd = 1.5)
dev.off()
truesize(0.10, adj, n, k, m)

pdf("graphs/densityPlot-slide.pdf", height = 3, width = 3)
par(mai = c(0.5, 0.5, 0, 0))
plot(c(xseq, xseq), c(dFtrue(xseq, adj, n, k, m), 
	df(xseq, m, n-k)), type = "n", las = 1, ylab = "f(x)", xlab = "x")
xx <- c(seq(qf(0.9, m, n-k), 4, 0.01), 3.979568, qf(0.9, m, n-k))
yy <- c(dFtrue(seq(qf(0.9, m, n-k), 4, 0.01), adj, n, k, m), 0, 0)
polygon(xx, yy, col = "gray", border = NA)
curve(df(x, m, n-k), -1, 4, 600, add = T, col = "black", lwd = 1.8)
curve(dFtrue(x, adj, n, k, m), -1, 4, 600, add = T, col = "red", lwd = 1.8)
dev.off()
