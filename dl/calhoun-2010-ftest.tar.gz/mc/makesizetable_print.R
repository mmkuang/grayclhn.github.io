load("mc/makesizetable.Rdata")

MakeTable <- function(MCSubFrame, StatNames, StatLabels = StatNames, dists) {
  MCSubFrame <- subset(MCSubFrame, k != 0.25 & n != 200)
  
  if (length(StatNames) != length(StatLabels))
    stop("StatNames and StatLabels must be the same length vectors")

  MCSubFrame$dist <- ifelse(is.na(MCSubFrame$edf), "Exponential", sprintf("$t(%d)$", MCSubFrame$edf))
  ## awkard code that generates the latex code for our table.  This
  ## ensures that we have horizontal bars separating the degrees of
  ## freedom, and have the size of each statistic next to eachother.
  SetupTex <- paste("\\begin{tabular}{clr|",
                     paste(rep(paste(rep("r", length(StatNames)), collapse = ""),
                               length(unique(MCSubFrame$dist))), collapse = "|"),
                     "}\n", collapse = "")
  ## set up multi-column labels -- list the error degrees of freedom
  LabelTex1 <- paste("\\\\&&&",
                    paste(sprintf("\\multicolumn{%d}{c}{%s}", length(StatNames), dists),
                          collapse = " & "),
                    "\\\\\n")
  ## second row of column labels -- list the statistics
  LabelTex2 <- paste("$q$ & $k/n$ & $n$ &",
                     paste(rep(StatLabels, length(dists)), collapse = " & "),
                     "\\\\\n\\hline\\hline")

  sortframe <- expand.grid(StatNames, dists)
  sortframe$o <- seq_along(sortframe$Var1)

  RowTex <- paste(unlist(lapply(split(MCSubFrame, subset(MCSubFrame, select = c(n, k, nrest))), function(d) {
    mframe <- merge(sortframe, d, by.x = c("Var1", "Var2"), by.y = c("stat", "dist"))
    sprintf("$%s$ & $%s$ & %d & %s ", d$nrest[1], d$k[1], d$n[1], 
            paste(round(100 * mframe[order(mframe$o),"r.prob"]), collapse = " & "))
  })), collapse =  "\\\\\n")
  
  paste(SetupTex, LabelTex1, LabelTex2, RowTex, "\\\\\\hline\n\\end{tabular}\n")
}

StatNames <- c("F", "Ghat", "N", "Wald")
StatLabels <- c("$\\hat F$", "$\\hat G$", "$N$", "Wald")
dists <- c("$t(5)$", "$t(30)$", "Exponential")
cat(MakeTable(subset(mc.hom, x == "norm", -x), StatNames, StatLabels, dists), file = "tables/size-normal-hom.tex")
cat(MakeTable(subset(mc.hom, x == "cauchy"), StatNames, StatLabels, dists), file = "tables/size-cauchy-hom.tex")
cat(MakeTable(subset(mc.het, x == "norm"), StatNames, StatLabels, dists), file = "tables/size-normal-het.tex")
cat(MakeTable(subset(mc.het, x == "cauchy"), StatNames, StatLabels, dists), file = "tables/size-cauchy-het.tex")

