2/4/2011

All of the monte carlo analyses for the paper, "Hypothesis Testing in
Linear Regression when K/N is Large" (Calhoun, 2010) can be run
automatically through the Makefile.  If you're unfamiliar with
Makefiles, you can find the manual for GNU make (which is what I use)
at

http://www.gnu.org/software/make/manual/make.html

Please let me know if the url is broken.  The command

make -n -B paper.pdf

lists all of the commands that need to be executed to compile the
paper.  The command "make -B paper.pdf" runs them all, which can take
a while, and the command "make paper.pdf"

runs the fewest commands necessary to compile the paper, given the
commands that have already been executed.  I'm not sure exactly what
this will do on your computer, since it depends on the timestamps of
each individual file.  It may not do anything, since I meant to
include all of the intermediate files in this archive.  The -n
argument tells make not to run any of the commands, so "make paper.pdf
-n" will tell you what "make paper.pdf" will do.

The empirical anlaysis is run
as a vignette for the package "ftestLargeK", which is available on my
website.  The results of that analysis are contained in the files:

tex/empirics-growthTeX.tex
tex/empirics-monetaryTeX.tex

The BibTeX file, AllRefs.bib, is a copy of the bibtex file I use for
all of my research, so it has many more references than I used in the
paper.

Please contact me if you find any errors or have any questions: 
Gray Calhoun <gcalhoun@iastate.edu>
