library(dplyr)
library(magrittr)
library(tidyr)

{d <-
  read.dta("AEJApp2008-0093_data/gdppcus.dta") %>%
    tbl_df %>%
    gather(year, gdp, -wbcode, -countryname) %>%
    separate(year, c("d", "year"), 7, convert = TRUE) %>%
    select(partner = wbcode, year, gdp) %>%
  inner_join(read.dta("AEJApp2008-0093_data/pop.dta") %>%
             tbl_df %>%
             gather(year, pop, -wbcode, -countryname) %>%
             separate(year, c("d", "year"), 3, convert = TRUE) %>%
             select(partner = wbcode, year, pop)) %>%
  inner_join(read.dta("AEJApp2008-0093_data/us_partner_report.dta") %>%
             tbl_df %>%
             filter(product != "Total") %>%
             select(-nomen, -partner_name, -product_name)) %>%
  inner_join(read.dta("AEJApp2008-0093_data/governance_filled.dta") %>%
             select(partner, year, corrupt) %>%
             mutate(corrupt = -corrupt)) %>%
  inner_join(read.dta("AEJApp2008-0093_data/distances.dta") %>%
             select(partner, dist)) %>%
  inner_join(read.dta("AEJApp2008-0093_data/met.dta"))} %>%
  write.csv("antique_imports.csv", row.names = FALSE)

read.dta("AEJApp2008-0093_data/us_partner_report.dta") %>%
    filter(product != "Total") %>%
    select(product, product_name) %>%
    unique %>%
    write.csv("product_categories.csv", row.names = FALSE)

read.dta("AEJApp2008-0093_data/gdppcus.dta") %>%
    select(partner = wbcode, name = countryname) %>%
    unique %>%
    write.csv("countries.csv", row.names = FALSE)
