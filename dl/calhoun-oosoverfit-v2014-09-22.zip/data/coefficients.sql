drop table if exists coefficients;
create table coefficients (i integer primary key, norm integer);
insert into coefficients (norm) values (0);
insert into coefficients (norm) values (1);
insert into coefficients (norm) values (2);