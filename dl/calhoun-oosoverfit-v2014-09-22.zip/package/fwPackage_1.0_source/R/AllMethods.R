setGeneric("ntest", function(object,...)
           standardGeneric("ntest"))

setGeneric("target", function(object,...)
           standardGeneric("target"))

setGeneric("CenteredPValue", function(object,...)
           standardGeneric("CenteredPValue"))

setGeneric("CenteredTTest", function(object,...)
           standardGeneric("CenteredTTest"))

setGeneric("expected.loss.test", function(object,...)
           standardGeneric("expected.loss.test"))

setGeneric("expected.loss.future", function(object,...)
           standardGeneric("expected.loss.future"))

setGeneric("nreg", function(object,...) standardGeneric("nreg"))


