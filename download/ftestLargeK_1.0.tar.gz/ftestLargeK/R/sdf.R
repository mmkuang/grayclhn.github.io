cterm.proposed <- function(n, k, nrst)
  nrst / (n - k)
cterm <-function(n, k, nrst)
  (n - k)^2 / (n - k - 2)^2 * (nrst + n - k - 2) / (n - k - 4) - 1 

sdf <-
function(Y, X.null, X.alt, P.null = P(X.null), P.alt = P(X.alt), useProposed = FALSE) {
    dim(Y) <- NULL
    X.null <- as.matrix(X.null)
    X.alt <- as.matrix(X.alt)

    nreg <- ncol(X.alt)
    nrst <- nreg - ncol(X.null)
    nobs <- length(Y)
    
    scaleTerm <- if(useProposed) {
      cterm.proposed(nobs, nreg, nrst)
    } else {
      cterm(nobs, nreg, nrst)
    }
    DAvg <- drop(crossprod((1 + scaleTerm) * diag(P.alt) - diag(P.null) - scaleTerm) / nrst)
    kEst <- max(ekurtosis(Y, X.null, P.null), 0)
    sqrt((2 + 2*scaleTerm + kEst*DAvg) / nrst)
}

sdf.pop <-
function(Y, X.null, X.alt, useProposed = FALSE) {
  dim(Y) <- NULL
  X.null <- as.matrix(X.null)
  X.alt <- as.matrix(X.alt)

  nobs <- length(Y)
  nreg <- ncol(X.alt)
  nrst <- nreg - ncol(X.null)

  if (useProposed) {
    sqrt(2 * (1 + cterm.proposed(nobs, nreg, nrst)) / nrst)
  } else {
    sqrt(2 * (1 + cterm(nobs, nreg, nrst)) / nrst)
  }
}
