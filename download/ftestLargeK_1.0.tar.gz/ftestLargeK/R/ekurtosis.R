ekurtosis <- function(Y, X, P.X = P(X)) {
  nobs <- nrow(X)
  nreg <- ncol(X)
  e <- Y - crossprod(P.X, Y)
  s2 <- drop(crossprod(e) / (nobs-nreg))

  wSigma  <- 6*nreg/nobs + mean(- 15*diag(P.X)^2 + 12*diag(P.X)^3 - 3*rowSums(P.X^4))
  wMuFour <- 1 - 4*nreg/nobs + mean(6*diag(P.X)^2 - 4*diag(P.X)^3 + rowSums(P.X^4))
  
  mean(e^4/s2^2)/wMuFour - wSigma/wMuFour - 3
}

