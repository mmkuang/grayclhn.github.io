P <- function(x,...) {
  QR <- qr(x,...)
  tcrossprod(qr.Q(QR)[, QR$pivot[seq_len(QR$rank)], drop = FALSE])
}
