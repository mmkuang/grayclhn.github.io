nstat <-
function(Y, X.null, X.alt, P.null = P(X.null), P.alt = P(X.alt)) {
  dim(Y) <- NULL
  X.null <- as.matrix(X.null)
  X.alt <- as.matrix(X.alt)
  
  nobs <- length(Y)
  nreg <- ncol(X.alt)
  nrst <- nreg - ncol(X.null)

  {(fstat(Y, X.null, X.alt, P.null, P.alt) - 1) /
    max(sdf.pop(Y, X.null, X.alt), sdf(Y, X.null, X.alt, P.null, P.alt))}
}

