AllStats <-
function(Y, X.null, X.alt, P.null = P(X.null), P.alt = P(X.alt)) {
  n <- length(Y)
  k <- dim(X.alt)[2]
  nrst <- k - dim(X.null)[2]
  ## We're going to use the estimate of the F random variable's
  ## standard deviation to scale the G-hat statistic to have variance
  ## equal to the population variance of the F random variable.  Since
  ## this scale factor is sometimes mis-estimated, we will ignore
  ## optimistic estimates that are smaller than the population
  ## standard deviation under normality.  This way we can be sure that
  ## the size of the new test is at least as good as the size of the
  ## original F-test.
  sdest <- sdf(Y, X.null, X.alt, P.null, P.alt)
  GScale1 <- min(1, sdf.pop(Y, X.null, X.alt)/sdf(Y, X.null, X.alt, P.null, P.alt))
  GScale2 <- min(1, sdf.pop(Y, X.null, X.alt, useProposed=TRUE) /
                 sdf(Y, X.null, X.alt, P.null, P.alt, useProposed=TRUE))

  ## Finally, calculate and return the three different tests.
  fvalue <- fstat(Y, X.null, X.alt, P.null, P.alt)
  gvalue1 <- GScale1*(fvalue-1) + 1
  gvalue2 <- GScale2*(fvalue-1) + 1
  nvalue <- (fvalue - 1) / sdest

  c(fvalue, gvalue1, gvalue2, nvalue)
}

