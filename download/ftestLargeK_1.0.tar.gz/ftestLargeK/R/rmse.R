rmse <-
function(x) return(sqrt(drop(crossprod(x))))

